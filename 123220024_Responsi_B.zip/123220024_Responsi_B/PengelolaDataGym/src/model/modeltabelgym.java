/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author M S I
 */
public class modeltabelgym extends AbstractTableModel{
    List<gym> dg;
    public modeltabelgym(List<gym>dm){
        this.dg = dg;
    }

    @Override
    public int getRowCount() {
        return dg.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0:
                return "nama_pemilik";
            case 1:
                return "nama_alat";
            case 2:
                return "nomor_telepon";
            case 3:
                return "waktu_sewa";
            case 4:
                return "biaya_sewa";
            default:
                return null;
        }
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dg.get(row).getnama_pemilik();
            case 1:
                return dg.get(row).getnama_alat();
            case 2:
                return dg.get(row).getnomor_telepon();
            case 3:
                return dg.get(row).getwaktu_sewa();
            case 4:
                return dg.get(row).getbiaya_sewa();
            default:
                return null;
        }
    }
}
