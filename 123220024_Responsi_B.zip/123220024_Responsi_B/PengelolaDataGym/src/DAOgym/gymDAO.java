/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOgym;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAOImplement.gymimplement;
/**
 *
 * @author M S I
 */
public class gymDAO implements gymimplement{
    Connection connection;

    final String select = "SELECT * FROM data_gym";
    final String insert = "INSERT INTO movie (nama_pemilik, nama_alat, nomor_telepon, waktu_sewa, biaya_sewa) VALUES (?, ?, ?, ?, ?)";
    final String update = "update movie set nama_alat=?, nomor_telepon=?, waktu_sewa=?, biaya_sewa=? where nama_pemilik=?";
    final String delete = "delete from data_gym where nama_pemilik=?";
    
    public gymDAO(){
        connection = connector.connection();
    }
    
    @Override
public void insert(gym p) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(insert);
        statement.setString(1, p.getnama_pemilik());
        statement.setString(2, p.getnama_alat());
        statement.setString(3, p.getnomor_telepon());
        statement.setDouble(4, p.getwaktu_sewa());
        statement.setDouble(5, p.getbiaya_sewa());
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

@Override
public void update(gym p) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(update);
        statement.setString(1, p.getnama_alat());
        statement.setString(2, p.getnomor_telepon());
        statement.setDouble(3, p.getwaktu_sewa());
        statement.setDouble(4, p.getbiaya_sewa());
        statement.setString(5, p.getnama_pemilik());
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

@Override
public void delete(String nama_pemilik) {
    PreparedStatement statement = null;
    try {
        statement = connection.prepareStatement(delete);
        statement.setString(1, nama_pemilik);
        statement.executeUpdate();
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


    
    }